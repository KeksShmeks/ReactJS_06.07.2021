

function Messege(props) {
    return <p>Мария, {props.text}</p>
}

export default Messege;

